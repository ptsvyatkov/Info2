
/*
 * All the methods which are needed to calculate Julian Date or Julian day number
 * 
 */
public class MyJulianDate implements JulianDate{
	
	private int day, month, year, julianDayNumber;
	private double julianDate;

	
	public MyJulianDate() {
	//	System.out.println(calculateJulianNumber(15, 12, 2019));
		
	}
	public MyJulianDate(int day, int month, int year) {
		this.day = day;
		this.month = month;
		this.year = year;
	}

	//sets the day to a valid day
	public void setDay(int day) {
		this.day = day;
	}
	
	//returns the day field
	public int getDay() {
		return day;
	}
	
	//sets the month to a valid month
	public void setMonth(int month) {
		this.month = month;
	}
	
	//returns the month field
	public int getMonth() {
		return month;
	}
	
	//sets the year to a valid year
	public void setYear(int year) {
		this.year = year;
	}
	//returns the year field
	public int getYear() {
		return year;
	}
	
	
	/*
	 * checking if the year is in the allowed range
	 */
	public boolean checkYear(int year) {
		if (year > -4714 && year < 3269) {
			return true;
		} else {
			System.out.println("The entered year doesn't fit to the range of the Julian Calendar.");
			return false;
		}
	}
	
	/*
	 * checking if the month is in the allowed range
	 * 
	 */
	public boolean checkMonth(int month) {
		if (month>0 && month<13) {
			return true;
		} else 
			return false;
		
	}
	
	/*
	 * checks if the entered day and month are valid
	 */
	public boolean checkDay(int day, int month) {
		//February
		if (month == 2 && day > 0 && day < 29) {
			return true;
		}
		//April,June
		if (month<8 && month != 2 && month%2==0 && day>0 && day < 31) {
			return true;
		} 
		//January,March,May,July
		else if (month<8 && month%2 !=0 && day >0 && day<32) {
			return true;
		} 
		//August,October,December
		else if (month > 7 && month%2==0 && day>0 && day<32) {
			return true;
		} 
		//September,October
		else if (month > 7 && month%2!=0 && day>0 && day<31) {
			return true;
		}
		else {
			return false;
		}
	}
	
	/*
	 * performs the necessary checks, if the entered day,month and
	 * year are correct then calculates them and returns the 
	 * julian date number, else if input is incorrect it returns -1
	 */
	public int calculateJulianNumber(int day, int month, int year) {
		
		if (checkDay(day, month) && checkMonth(month) && checkYear(year)) {
			julianDayNumber = (1461 * (year + 4800 + (month - 14)/12))/4 +
					(367 * (month - 2 - 12 * ((month - 14)/12)))/12 - 
					(3 * ((year + 4900 + (month - 14)/12)/100))/4 + day - 32075;
			return julianDayNumber;
		} 
		else 
			return -1;
		
	}
	
}
