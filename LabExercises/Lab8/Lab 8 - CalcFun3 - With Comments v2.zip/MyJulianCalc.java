import java.util.Calendar;
/*
 * Similar to what we did in Lab4, we are using the
 * getTodaysDate method to get the current date.
 * Introduced the new methods convertDateToJulian
 * and convertJulianToDate. Also changed the method
 * getWeekday to return the day.
 */
public class MyJulianCalc {
	
	private int dayToday, monthToday, yearToday;
	MyJulianDate myJulianDate;
	
	
	/*
	 * Constructor for this class
	 * creates a new MyJulianDate
	 * calls getTodaysDate
	 */
	public MyJulianCalc() {	
		myJulianDate = new MyJulianDate();
		getTodaysDate();
	}
	
	
	
	/*
	 * creates a new calendar instance, gets
	 * today's day, month and year and stores
	 * them in the respective variable
	 */
	public void getTodaysDate() {

	Calendar calendar = Calendar.getInstance();
	dayToday = calendar.get(Calendar.DAY_OF_MONTH);
	monthToday = calendar.get(Calendar.MONTH)+1;
	yearToday = calendar.get(Calendar.YEAR);

	}
		
	
	/*
	 * Takes a date as parameter, stores day,month and 
	 * year in a String array using split() on the
	 * parameter. It's important that the date is in 
	 * DD.MM.YYYY format. Parsing all three parts, then
	 * using them to calculate the julian date number
	 */
	 protected int convertDateToJulian(String date) {
		
	// splitting the date intoto 3 parts, we need
	// to use backslashes to escape the dot
	// https://stackoverflow.com/questions/33031764/split-function-with-dot-on-string-in-java
		 
	    String[] splitDate = date.split("\\.");
	    
	    int day = Integer.parseInt(splitDate[0]); 
	    int month = Integer.parseInt(splitDate[1]);
	    int year = Integer.parseInt(splitDate[2]);
	    
	    int jdn = myJulianDate.calculateJulianNumber(day, month, year);
	    			
	    return jdn;
	}
	
	
	
	/*
	 * Uses a modulo operation on the Julian day number
	 * to determine the weekday and returns values from
	 * 0 to 6, where 0 is for Monday and 6 is for Sunday.
	 * printing in console omitted
	 */
	public String getWeekday (int jdn) {

		if (((jdn%7)) == 0 ) {
			return "Monday";
		}
		if (((jdn%7)) == 1 ) {
			return "Tuesday";
		}
		if (((jdn%7)) == 2 ) {
			return "Wednesday";
		}
		if (((jdn%7)) == 3 ) {
			return "Thursday";
		}
		if (((jdn%7)) == 4 ) {
			return "Friday";
		}
		if (((jdn%7)) == 5 ) {
			return "Saturday";
		}
		if (((jdn%7)) == 6 ) {
			return "Sunday";
		}
		return "Invalid date input";
	}
	
	
	/*
	 * Takes a julian date number as a parameter,
	 * does some calculations with it and stores
	 * the day,month and year in 3 different int 
	 * variables. Prints the date to the console 
	 * in DD.MM.YYYY format and returns it as well.
	 * Using the formula from 
	 * https://en.wikipedia.org/wiki/Julian_day
	 */
	public String convertJulianToDate(int jdn) {
	  int f = jdn + 1401 + (((4*jdn+274277)/146097)*3)/4+(-38);
	  int e = 4*f+3;
	  int g = (e%1461)/4;
	  int h = 5*g+2;
		
	  int day = (h%153)/5+1;
      int month = ((h/153+2)%12)+1;
	  int year = (e/1461)-4716+(12+2-month)/12;
	  System.out.println("Date: " + day + "." + month + "." + year);
	  return "" + day + "." + month + "." + year;
	}	
}
