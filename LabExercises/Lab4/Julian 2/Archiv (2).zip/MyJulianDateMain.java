
public class MyJulianDateMain {
	
	public static void main(String[] args) {
		MyJulianDate myJulianDate = new MyJulianDate();
		MyBirthday birthday = new MyBirthday();

		birthday.select();
//		birthday.calculateDaysWithTime();
//		birthday.getSystemDate();
//		birthday.input();
//		birthday.calculateDayofBirth();
//		birthday.calculateDays();
//		birthday.printAgeInDays();


	}
}
