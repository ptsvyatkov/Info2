
public class UnderflowException extends Exception{
	public UnderflowException() {
		System.err.println("Stack is empty");
	}
}
