
public class OverflowException extends Exception {
	public OverflowException() {
		System.err.println("Stack is full");
	}
}
