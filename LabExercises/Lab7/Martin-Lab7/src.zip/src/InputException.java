
public class InputException extends Exception{
	public InputException() {
		System.err.println("Your input was invalid");
	}
}
